from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
# from urllib.parse import quote #message parsing into url
import time
with open("message.txt",'r') as file:
    msg = file.read()

image_path = r"C:\Users\akash\PycharmProjects\WhatsappBulkMessage\sample_img.png" #required to add absolute copy path
numbers = []
country_code = 91
#times :- (Set according to your device and network speed by hit and trial method)
login_time = 20
css_load_time = 25
button_time = 2
messsage_time = 5



with open('numbers.txt','r') as file:
    for num in file.readlines():
        numbers.append(num.rstrip()) #rstrip method removes \n char present in each num


driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

link = 'https:///web.whatsapp.com'
driver.get(link)
time.sleep(login_time) #For login whatsapp

for num in numbers:
    link2 = f'https://web.whatsapp.com/send/?phone={country_code}{num}'
    driver.get(link2)
    time.sleep(css_load_time) #Waiting for css loading
    attach_button = driver.find_element(By.CSS_SELECTOR,"._1OT67")
    attach_button.click()
    time.sleep(button_time)
    image_input = driver.find_element(By.XPATH,r'//*[@id="main"]/footer/div[1]/div/span[2]/div/div[1]/div[2]/div/span/div/ul/div/div[2]/li/div/input')
    image_input.send_keys(image_path)
    time.sleep(button_time)
    action = ActionChains(driver)
    for line in msg.split('\n'):
        action.send_keys(line)
        action.key_down(Keys.SHIFT).send_keys(Keys.ENTER).key_up(Keys.SHIFT)
    action.send_keys(Keys.ENTER)
    action.perform()
    time.sleep(messsage_time)

time.sleep(2000)
