from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from urllib.parse import quote #message parsing into url
import time
with open("message.txt",'r') as file:
    msg = file.read()

msg = quote(msg) #reassigning message with quoted message



numbers = []
country_code = 91
#times :- (Set according to your device and network speed by hit and trial method)
login_time = 20
load_time = 10
messsage_time = 5

with open('numbers.txt','r') as file:
    for num in file.readlines():
        numbers.append(num.rstrip()) #rstrip method removes \n char present in each num


driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

link = 'https:///web.whatsapp.com'
driver.get(link)
time.sleep(login_time) #For login whatsapp


for num in numbers:
    link2 = f'https://web.whatsapp.com/send/?phone={country_code}{num}&text={msg}'
    driver.get(link2)
    time.sleep(load_time)
    action = ActionChains(driver)
    action.send_keys(Keys.ENTER)
    action.perform()
    time.sleep(messsage_time)

